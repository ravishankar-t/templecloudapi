var app = require('./index');
var jwt=require('jsonwebtoken')


var port = process.env.PORT || 3000;
//console.log(process.env)
/*app.use(function(req,res,next){
if(req.headers && req.headers.autohorization && req.headers.authorization.spli(' ')[0]==='JWT'){
jwt.verify(req.headers.auothorization.split(' ')[1],'SSMCL',function(err,decode){
  if(err)req.user=undefined;
  req.user=decode;
  next();
})
} else{
  req.user=undefined
  next()
}
var token = req.headers['x-access-token'];
  if (!token) return res.status(401).send({ auth: false, message: 'No token provided.' });
  
  jwt.verify(token, config.secret, function(err, decoded) {
    if (err) return res.status(500).send({ auth: false, message: 'Failed to authenticate token.' });
    
    res.status(200).send(decoded);
  });

})


*/

app.use(function(req, res, next) {
    res.setHeader('Access-Control-Allow-Origin','*')
   res.header("Access-Control-Allow-Headers",'Content-Type, Authorization, Content-Length, X-Requested-With,Accept');
   res.header('Access-Control-Allow-Credentials', true)
    res.header("Access-Control-Allow-Methods", "GET, POST, PATCH, PUT, DELETE, OPTIONS")
    next();
});

app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// If our applicatione encounters an error, we'll display the error and stacktrace accordingly.
app.use(function(err, req, res, next) {
  res.status(err.status || 500);
  res.send(err);
});


var server = app.listen(port, function() {
  console.log('Express server listening on port ' + port);
});