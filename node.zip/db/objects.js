var colls={
  donations:"donations",
  donationtype:"donationtype",
  sevatype:"sevatype",
  sevas:"sevas"  ,
  gallerycategory:"gallerycategory",
  gallerystore:"gallerystore",
  users:"users",
  transactions:"transactions",
  issuemaster:"issuemaster",
  issueitems:"issueitems",
  stores:"stores",
  config:"config",
  units:"units",
  hsncodes:"hsncodes",
  itemmaster:"itemmaster",
  organisaction:"organisation",
  session:"session",
 


}

var messages={
    TCONNFAIL:"Connection to Database failed",
    TFAIL:"fail",
    TSUCCESS:"success",

}

module.exports ={
    colls:colls,
    messages:messages
}