var router = require('./index')

var db = require('../db/systemdb')

router.post('/saveconfig',function(req,res){

})

router.post('/getconfig',function(req,res){

})



module.exports = router
