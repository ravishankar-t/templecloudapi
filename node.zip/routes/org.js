var router = require('./index')
var db=require('../db/orgdb')