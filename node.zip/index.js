var express = require('express');
var app = express();
var cors = require('cors')
var mongo= require('mongodb');

var bodyParser = require('body-parser');
app.use(cors({origin: '*'}));
var donationroute = require('./routes/donation')
app.use(express.static('public'));
app.use(express.json({limit: '50mb'}));
app.use(bodyParser.urlencoded({extended:true,limit: '50mb'}));
app.use('/donations',donationroute)

module.exports = app;

